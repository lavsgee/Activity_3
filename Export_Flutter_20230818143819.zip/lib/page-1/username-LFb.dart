import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 71;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // username2WM (6:44)
        width: double.infinity,
        height: 29*fem,
        child: Text(
          'Username',
          style: SafeGoogleFont (
            'Kadwa',
            fontSize: 14*ffem,
            fontWeight: FontWeight.w400,
            height: 2.01*ffem/fem,
            color: Color(0xff000000),
          ),
        ),
      ),
          );
  }
}