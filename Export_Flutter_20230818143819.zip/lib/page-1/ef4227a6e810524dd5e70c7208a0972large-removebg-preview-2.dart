import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 56;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // ef4227a6e810524dd5e70c7208a097 (8:118)
        width: double.infinity,
        height: 77*fem,
        child: Image.asset(
          'assets/page-1/images/ef4227a6e810524dd5e70c7208a0972large-removebg-preview-2.png',
          fit: BoxFit.cover,
        ),
      ),
          );
  }
}