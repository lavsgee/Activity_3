import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/rectangle-11.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-4.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-5.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-8.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-9.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-10.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-7.dart';
// import 'package:myapp/page-1/f86cf53ceeb5490991ca4d5ef89f7d60-6.dart';
// import 'package:myapp/page-1/loginanimi-removebg-preview-1-1.dart';
// import 'package:myapp/page-1/online-tindahan.dart';
// import 'package:myapp/page-1/online-tindahan-x9X.dart';
// import 'package:myapp/page-1/istockphoto-1131819996-170667a-removebg-preview.dart';
// import 'package:myapp/page-1/istockphoto-1131819996-170667a-removebg-preview-cKs.dart';
// import 'package:myapp/page-1/login.dart';
// import 'package:myapp/page-1/sign-up.dart';
// import 'package:myapp/page-1/lom-general-service-pages-v4-up03-removebg-preview-1.dart';
// import 'package:myapp/page-1/welcome-back.dart';
// import 'package:myapp/page-1/register.dart';
// import 'package:myapp/page-1/register-u6Z.dart';
// import 'package:myapp/page-1/login-to-your-account.dart';
// import 'package:myapp/page-1/create-your-account.dart';
// import 'package:myapp/page-1/rectangle-1.dart';
// import 'package:myapp/page-1/rectangle-4.dart';
// import 'package:myapp/page-1/rectangle-6.dart';
// import 'package:myapp/page-1/rectangle-7.dart';
// import 'package:myapp/page-1/rectangle-5.dart';
// import 'package:myapp/page-1/rectangle-2.dart';
// import 'package:myapp/page-1/username.dart';
// import 'package:myapp/page-1/username-LFb.dart';
// import 'package:myapp/page-1/password.dart';
// import 'package:myapp/page-1/online-tindahan-shopping-cart.dart';
// import 'package:myapp/page-1/password-WU9.dart';
// import 'package:myapp/page-1/confirm-password.dart';
// import 'package:myapp/page-1/submit.dart';
// import 'package:myapp/page-1/cancel.dart';
// import 'package:myapp/page-1/password-xGq.dart';
// import 'package:myapp/page-1/email.dart';
// import 'package:myapp/page-1/email-Zzh.dart';
// import 'package:myapp/page-1/anonymous-user-circle-icon-vector-18958255-removebg-preview-1.dart';
// import 'package:myapp/page-1/anonymous-user-circle-icon-vector-18958255-removebg-preview-2.dart';
// import 'package:myapp/page-1/rectangle-3.dart';
// import 'package:myapp/page-1/remember-me.dart';
// import 'package:myapp/page-1/forgot-password.dart';
// import 'package:myapp/page-1/dont-have-an-account-sign-up.dart';
// import 'package:myapp/page-1/istockphoto-1131819996-170667a-removebg-preview-oiZ.dart';
// import 'package:myapp/page-1/istockphoto-1131819996-170667a-removebg-preview-Fku.dart';
// import 'package:myapp/page-1/login-3Cu.dart';
// import 'package:myapp/page-1/comercio-electronico-removebg-preview-1.dart';
// import 'package:myapp/page-1/e4beacb11b227491c3399-removebg-preview-1.dart';
// import 'package:myapp/page-1/removebg-preview-1.dart';
// import 'package:myapp/page-1/png-clipart-computer-icons-skype-icon-design-change-password-logo-internet-removebg-preview-1.dart';
// import 'package:myapp/page-1/png-clipart-computer-icons-skype-icon-design-change-password-logo-internet-removebg-preview-2.dart';
// import 'package:myapp/page-1/rectangle-8.dart';
// import 'package:myapp/page-1/rectangle-9.dart';
// import 'package:myapp/page-1/house-logo-png-home-address-logo-png-removebg-preview-1.dart';
// import 'package:myapp/page-1/download-blue-search-icon-button-png-11640084027s0fkuhz2lb-removebg-preview-1.dart';
// import 'package:myapp/page-1/download10-removebg-preview-1.dart';
// import 'package:myapp/page-1/download10-removebg-preview-2.dart';
// import 'package:myapp/page-1/download11-removebg-preview-1.dart';
// import 'package:myapp/page-1/chuckie-nestle-chocolate-flavor-drink-600x600-removebg-preview-1.dart';
// import 'package:myapp/page-1/hgwholefront0-removebg-preview-1.dart';
// import 'package:myapp/page-1/milo-detail-brand-page-removebg-preview-1.dart';
// import 'package:myapp/page-1/chuckie.dart';
// import 'package:myapp/page-1/cadbury.dart';
// import 'package:myapp/page-1/magic-sarap.dart';
// import 'package:myapp/page-1/stick-o.dart';
// import 'package:myapp/page-1/nova.dart';
// import 'package:myapp/page-1/c2.dart';
// import 'package:myapp/page-1/lactaid.dart';
// import 'package:myapp/page-1/milo.dart';
// import 'package:myapp/page-1/download25-removebg-preview-1.dart';
// import 'package:myapp/page-1/removebg-preview-1-PUd.dart';
// import 'package:myapp/page-1/removebg-preview-2.dart';
// import 'package:myapp/page-1/ef4227a6e810524dd5e70c7208a0972large-removebg-preview-1.dart';
// import 'package:myapp/page-1/ef4227a6e810524dd5e70c7208a0972large-removebg-preview-2.dart';
// import 'package:myapp/page-1/stiko-junior-strawberry-380g2-removebg-preview-1.dart';
// import 'package:myapp/page-1/removebg-preview-1-1.dart';
// import 'package:myapp/page-1/removebg-preview-1-85P.dart';
// import 'package:myapp/page-1/tanduay.dart';
// import 'package:myapp/page-1/rectangle-10.dart';
// import 'package:myapp/page-1/rectangle-12.dart';
// import 'package:myapp/page-1/rectangle-13.dart';
// import 'package:myapp/page-1/rectangle-14.dart';
// import 'package:myapp/page-1/rectangle-17.dart';
// import 'package:myapp/page-1/rectangle-18.dart';
// import 'package:myapp/page-1/rectangle-15.dart';
// import 'package:myapp/page-1/rectangle-16.dart';
// import 'package:myapp/page-1/products.dart';
// import 'package:myapp/page-1/total-item-116.dart';
// import 'package:myapp/page-1/checkout.dart';
// import 'package:myapp/page-1/total.dart';
// import 'package:myapp/page-1/total-RDK.dart';
// import 'package:myapp/page-1/quantity.dart';
// import 'package:myapp/page-1/quantity-E89.dart';
// import 'package:myapp/page-1/search-for-products.dart';
// import 'package:myapp/page-1/welcome-to-chat.dart';
// import 'package:myapp/page-1/price.dart';
// import 'package:myapp/page-1/.dart';
// import 'package:myapp/page-1/-iRF.dart';
// import 'package:myapp/page-1/-Wdw.dart';
// import 'package:myapp/page-1/-Xqs.dart';
// import 'package:myapp/page-1/-9uB.dart';
// import 'package:myapp/page-1/-mSh.dart';
// import 'package:myapp/page-1/-NzD.dart';
// import 'package:myapp/page-1/-npy.dart';
// import 'package:myapp/page-1/-bJZ.dart';
// import 'package:myapp/page-1/-bUu.dart';
// import 'package:myapp/page-1/-peV.dart';
// import 'package:myapp/page-1/n1ix6fhl-removebg-preview-1.dart';
// import 'package:myapp/page-1/download12-removebg-preview-1-1.dart';
// import 'package:myapp/page-1/welcome-to-watsons-official-store-how-can-we-assist-you.dart';
// import 'package:myapp/page-1/hi-thanks-for-following-our-shop-here-are-some-deals-just-for-you-valid-for-a-limited.dart';
// import 'package:myapp/page-1/click-your-concern-below.dart';
// import 'package:myapp/page-1/welcome-how-may-i-help-you.dart';
// import 'package:myapp/page-1/logo-unilab-header-removebg-preview.dart';
// import 'package:myapp/page-1/c1e01a8d6b-removebg-preview-1.dart';
// import 'package:myapp/page-1/bench-logo-removebg-preview-1.dart';
// import 'package:myapp/page-1/cetaphillogo-removebg-preview-1.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
